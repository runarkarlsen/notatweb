UPDATE bruker SET passord_hash = 'pbkdf2:sha256:260000$xsY7z2KNhHM9FMVn$eaf067a73ee6dffe7449cc236312de9fe120642673f954a4c9d705c12c4bc316' WHERE brukernavn = 'admin';
